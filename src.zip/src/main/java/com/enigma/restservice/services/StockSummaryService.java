package com.enigma.restservice.services;

import com.enigma.restservice.models.stock.StockSummary;

import java.util.List;

public interface StockSummaryService {
    public List<StockSummary> stockSummary();
}
